import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  ChevronDown,
  ChevronRight,
  Gavel,
  Users,
  UserCheck,
  UserX,
  Scale,
  FileText,
  Calendar,
  Briefcase,
  Settings,
  Building,
  Shield,
  Archive,
  Search,
  BarChart3,
  Menu,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { cn } from '@/lib/utils';

interface SidebarProps {
  isCollapsed: boolean;
  onToggle: () => void;
}

interface MenuItem {
  key: string;
  icon: React.ComponentType<{ className?: string }>;
  children?: MenuItem[];
}

const Sidebar: React.FC<SidebarProps> = ({ isCollapsed, onToggle }) => {
  const { t, isRTL } = useLanguage();
  const [expandedItems, setExpandedItems] = useState<string[]>(['customer_service', 'reports', 'settings']);

  const menuItems: MenuItem[] = [
    {
      key: 'cases',
      icon: Gavel,
    },
    {
      key: 'customer_service',
      icon: Users,
      children: [
        { key: 'clients', icon: Users },
        { key: 'agents', icon: UserCheck },
        { key: 'clients_no_agents', icon: UserX },
      ],
    },
    {
      key: 'lawyers',
      icon: Scale,
    },
    {
      key: 'reports',
      icon: BarChart3,
      children: [
        { key: 'sessions', icon: Calendar },
        { key: 'procedures', icon: FileText },
        { key: 'services', icon: Briefcase },
      ],
    },
    {
      key: 'settings',
      icon: Settings,
      children: [
        { key: 'office_settings', icon: Building },
        { key: 'users_roles', icon: Shield },
      ],
    },
    {
      key: 'archive',
      icon: Archive,
    },
    {
      key: 'courts_search',
      icon: Search,
    },
  ];

  const toggleExpanded = (key: string) => {
    setExpandedItems(prev =>
      prev.includes(key)
        ? prev.filter(item => item !== key)
        : [...prev, key]
    );
  };

  const isExpanded = (key: string) => expandedItems.includes(key);

  const renderMenuItem = (item: MenuItem, level = 0) => {
    const hasChildren = item.children && item.children.length > 0;
    const expanded = isExpanded(item.key);
    const IconComponent = item.icon;

    return (
      <div key={item.key} className="w-full">
        {hasChildren ? (
          <button
            onClick={() => toggleExpanded(item.key)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
              "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground glow-hover",
              level > 0 && "ml-4 rtl:ml-0 rtl:mr-4",
              isCollapsed && "justify-center px-2"
            )}
          >
            <IconComponent className={cn("h-5 w-5 flex-shrink-0", isCollapsed && "h-6 w-6")} />
            {!isCollapsed && (
              <>
                <span className="flex-1 text-left rtl:text-right">
                  {t(`nav.${item.key}`)}
                </span>
                {expanded ? (
                  <ChevronDown className="h-4 w-4" />
                ) : (
                  <ChevronRight className={cn("h-4 w-4", isRTL && "rotate-180")} />
                )}
              </>
            )}
          </button>
        ) : (
          <NavLink
            to={`/dashboard/${item.key}`}
            className={({ isActive }) =>
              cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground glow-hover",
                isActive && "bg-sidebar-primary text-sidebar-primary-foreground shadow-glow",
                level > 0 && "ml-4 rtl:ml-0 rtl:mr-4",
                isCollapsed && "justify-center px-2"
              )
            }
          >
            <IconComponent className={cn("h-5 w-5 flex-shrink-0", isCollapsed && "h-6 w-6")} />
            {!isCollapsed && (
              <span className="flex-1 text-left rtl:text-right">
                {t(`nav.${item.key}`)}
              </span>
            )}
          </NavLink>
        )}

        {hasChildren && expanded && !isCollapsed && (
          <div className="mt-1 space-y-1 animate-accordion-down">
            {item.children?.map(child => renderMenuItem(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {/* Mobile Overlay */}
      {!isCollapsed && (
        <div 
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 lg:hidden"
          onClick={onToggle}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-0 z-50 h-full glass border-r border-sidebar-border transition-all duration-300 lg:relative lg:translate-x-0",
          isCollapsed ? "w-16 -translate-x-full lg:translate-x-0" : "w-64 translate-x-0",
          isRTL && "left-auto right-0"
        )}
      >
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="flex h-16 items-center justify-between px-4 border-b border-sidebar-border">
            {!isCollapsed && (
              <h2 className="text-lg font-semibold bg-gradient-primary bg-clip-text text-transparent">
                {t('nav.dashboard')}
              </h2>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggle}
              className="h-8 w-8 hover:bg-sidebar-accent glow-hover"
            >
              {isCollapsed ? <Menu className="h-4 w-4" /> : <X className="h-4 w-4" />}
            </Button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto p-4 space-y-2">
            {menuItems.map(item => renderMenuItem(item))}
          </nav>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;