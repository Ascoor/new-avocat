import React, { createContext, useContext, useEffect, useState } from 'react';

export type Language = 'ar' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

// Translations object
const translations = {
  ar: {
    // Navigation
    'nav.dashboard': 'لوحة التحكم',
    'nav.cases': 'القضايا',
    'nav.customer_service': 'خدمة العملاء',
    'nav.clients': 'العملاء',
    'nav.agents': 'وكلاء العملاء',
    'nav.clients_no_agents': 'عملاء بدون وكلاء',
    'nav.lawyers': 'المحامون',
    'nav.reports': 'التقارير',
    'nav.sessions': 'الجلسات',
    'nav.procedures': 'إجراءات القضايا',
    'nav.services': 'الخدمات',
    'nav.settings': 'الإعدادات',
    'nav.office_settings': 'إعدادات المكتب',
    'nav.users_roles': 'المستخدمين والصلاحيات',
    'nav.archive': 'الأرشيف',
    'nav.courts_search': 'البحث في المحاكم',
    
    // Auth
    'auth.login': 'تسجيل الدخول',
    'auth.signup': 'إنشاء حساب',
    'auth.email': 'البريد الإلكتروني',
    'auth.password': 'كلمة المرور',
    'auth.name': 'الاسم',
    'auth.logout': 'تسجيل الخروج',
    'auth.profile': 'الملف الشخصي',
    
    // Landing
    'landing.hero.title': 'نظام إدارة المكاتب القانونية المتطور',
    'landing.hero.subtitle': 'حلول رقمية شاملة لإدارة القضايا والعملاء والمحامين',
    'landing.cta.signup': 'ابدأ الآن',
    'landing.cta.login': 'تسجيل الدخول',
    
    // Common
    'common.welcome': 'مرحباً',
    'common.loading': 'جاري التحميل...',
    'common.save': 'حفظ',
    'common.cancel': 'إلغاء',
    'common.delete': 'حذف',
    'common.edit': 'تعديل',
    'common.add': 'إضافة',
  },
  en: {
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.cases': 'Cases',
    'nav.customer_service': 'Customer Service',
    'nav.clients': 'Clients',
    'nav.agents': 'Client Agents',
    'nav.clients_no_agents': 'Clients without Agents',
    'nav.lawyers': 'Lawyers',
    'nav.reports': 'Reports',
    'nav.sessions': 'Sessions',
    'nav.procedures': 'Legal Procedures',
    'nav.services': 'Services',
    'nav.settings': 'Settings',
    'nav.office_settings': 'Office Settings',
    'nav.users_roles': 'Users & Permissions',
    'nav.archive': 'Archive',
    'nav.courts_search': 'Courts Search',
    
    // Auth
    'auth.login': 'Login',
    'auth.signup': 'Sign Up',
    'auth.email': 'Email',
    'auth.password': 'Password',
    'auth.name': 'Name',
    'auth.logout': 'Logout',
    'auth.profile': 'Profile',
    
    // Landing
    'landing.hero.title': 'Advanced Legal Office Management System',
    'landing.hero.subtitle': 'Comprehensive digital solutions for managing cases, clients, and lawyers',
    'landing.cta.signup': 'Get Started',
    'landing.cta.login': 'Login',
    
    // Common
    'common.welcome': 'Welcome',
    'common.loading': 'Loading...',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.delete': 'Delete',
    'common.edit': 'Edit',
    'common.add': 'Add',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    const stored = localStorage.getItem('avocat_language');
    return (stored as Language) || 'ar';
  });

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem('avocat_language', language);
  }, [language]);

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations[typeof language]] || key;
  };

  const value = {
    language,
    setLanguage,
    t,
    isRTL: language === 'ar'
  };

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};